var cy = window.cy = cytoscape({
  container: document.getElementById('cy'),

  boxSelectionEnabled: true,

  style: [
    {
      selector: 'node',
      css: {
        'content': 'data(label)',
        'text-valign': 'center',
        'text-halign': 'center',
		'shape': 'ellipse',
		'height': 80,
		'width': 120,
		'background-opacity': 0.7,
		'word-wrap': 'break-word'
      }
    },
    {
      selector: ':parent',
      css: {
        'text-valign': 'top',
        'text-halign': 'center',
      }
    },
    {
      selector: 'edge',
      css: {
        'curve-style': 'bezier',
        'target-arrow-shape': 'triangle',
		'line-color': 'green'
      }
    }
  ],

  elements: {
    nodes: [
      { data: { id: '2029', label: '2029' } },
      { data: { id: '1984', label: '1984' } },
      { data: { id: '1995', label: '1995' } },
      { data: { id: '1955', label: '1955' } },
      { data: { id: '1985', label: '1985' } },
      { data: { id: '1955-11-05T06:15', label: '1955-11-05 06:15', parent: '1955' } },
      { data: { id: '1955-11-12T06:00', label: '1955-11-12 06:00', parent: '1955' } },
      { data: { id: '1985-10-26T01:24', label: '1985-10-26 01:24', parent: '1985' } },
      { data: { id: '1985-10-26T21:00', label: '1985-10-26 21:00', parent: '1985' } },
      { data: { id: '1985-10-27T11:00', label: '1985-10-27 11:00', parent: '1985' } },
	  { data: { id: '1900', label: '1900' }, classes: 'autorotate'  },
	  { data: { id: '1900-01-05', label: '1900-01-05', parent: 'The Time Machine' } },
	  { data: { id: '1917-09-13', label: '1917-09-13', parent: 'The Time Machine' } },
	  { data: { id: '1940-06-19', label: '1940-06-19', parent: 'The Time Machine' } },
	  { data: { id: '1966-08-18', label: '1966-08-18', parent: 'The Time Machine' } },
	  { data: { id: '802701-10-12', label: '802701-10-12', parent: 'The Time Machine' } },
	  

	  
    ],
    edges: [
      { data: { id: '1', source: '2029', target: '1984', label: 'test'  }, classes: 'autorotate' },
      { data: { id: '2', source: '2029', target: '1984' } },
	  { data: { id: '3', source: '2029', target: '1995' } },
      { data: { id: '4', source: '2029', target: '1995' } },
      { data: { id: '5', source: '1985-10-26T01:24', target: '1955-11-12T06:00' } },
	  { data: { id: '6', source: '1900-01-05', target: '1917-09-13' } },	
	  { data: { id: '7', source: '1917-09-13', target: '1940-06-19' } },	
	  { data: { id: '8', source: '1940-06-19', target: '1966-08-18' } },	
	  { data: { id: '9', source: '1966-08-18', target: '802701-10-12' } },	
	  { data: { id: '10', source: '802701-10-12', target: '1900-01-05' } },	
    ]
  },

  layout: {
	name: 'concentric',
	concentric: function(n){ return n.id() === 'j' ? 200 : 0; },
	levelWidth: function(nodes){ return 100; },
	minNodeSpacing: 100,
	fit: true,
	directed: true,
  },
});

